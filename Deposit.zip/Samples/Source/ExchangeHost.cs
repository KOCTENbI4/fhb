/**********************************************************************************\

    ExchangeHost
    This module contains a sample AuthorizationHost Object which implements
    an exchange rate query.  No real comms is implemented, instead information
    is retrieved from a hard-coded table.
    
    Copyright (c) 2007 - 2017 KAL

\**********************************************************************************/
using System.Collections.Generic;
using System.Threading;
using K3A.Common;
using K3A.Hosts;

namespace Samples
{
    /// <summary>
    /// Sample host object implementing General Inquiry method in order to retrieve exchange rate information.
    /// </summary>
    public class ExchangeHost : TransactionHost
    {
        public ExchangeHost()
            : base("ExchangeHost")
        {
        }

        public ExchangeHost(string id)
            : base("ExchangeHost", id)
        {
        }

        /// <summary>
        /// Required override from Host base class
        /// </summary>
        public override void Enable()
        {
            // This method should check if the host can be connected to and change
            // the status to Available or NotAvailable accordingly.
            // For demo, we just set status to Available
            Status = HostStatus.Available;
        }

        /// <summary>
        /// Required override from Host base class
        /// </summary>
        public override void Disable()
        {
            // This method should close any sessions with the host and disconnect
            // from any hardware resources used.  Then update status to Disabled.
            Status = HostStatus.Disabled;
        }

        /// <summary>
        /// Required override from Host base class
        /// </summary>
        public override bool TestConnection()
        {
            // This method should test if host can be contacted.
            // For demo purposes, we always report success.
            return true;
        }

        /// <summary>
        /// Supports GeneralInquiry type only, and only for getting exchange rate from host.
        /// </summary>
        /// <returns></returns>
        public override AuthorizationResult Inquiry(InquiryType type, string subType, Dictionary<string, object> inputFields, CashAmount txnAmount, CashAmount txnCharge, Account account, CustomerMedia media, byte[] PINBlock)
        {
            // Check input parameters: the only inquiry this object supports is an exchange rate lookup
            if (type != InquiryType.General)
                return new AuthorizationResult(AuthorizationStatus.Declined, TransactionNumber);

            string requestType = subType;
            if (requestType != "ExchangeRate")
                return new AuthorizationResult(AuthorizationStatus.Declined, TransactionNumber);

            // Increment transaction number maintained by base class.
            IncrementTransactionNumber();

            object fromCurrencyObj = null, toCurrencyObj = null;
            bool ok = inputFields.TryGetValue("FromCurrency", out fromCurrencyObj) &&
                      inputFields.TryGetValue("ToCurrency", out toCurrencyObj);
            if (!ok)
                return new AuthorizationResult(AuthorizationStatus.Declined, TransactionNumber);

            // Request looks OK.  Simulate a delay retrieving information.
            Thread.Sleep(3000);

            // Actually we'll get the rate from this table.  Only add rates for USD
            // as that's all we'll get
            Dictionary<string, CashAmount> exchangeRates = new Dictionary<string, CashAmount>();
            exchangeRates.Add("USD-EUR", new CashAmount("EUR", 7713));
            exchangeRates.Add("USD-JPY", new CashAmount("JPY", 12143));
            exchangeRates.Add("USD-GBP", new CashAmount("GBP", 5104));

            CashAmount rate;
            string conversion = fromCurrencyObj.ToString() + "-" + toCurrencyObj.ToString();
            ok = exchangeRates.TryGetValue(conversion, out rate);
            if (!ok)
                return new AuthorizationResult(AuthorizationStatus.Declined, TransactionNumber);

            AuthorizationResult result = new AuthorizationResult(AuthorizationStatus.Authorized, TransactionNumber);
            result.Amount = rate;
            return result;
        }

        // NOTE: Since this demo host only supports the exchange rate lookup, we
        // don't implement any other virtual methods exposed from AuthorizationHost
        // Any other requested transactions will be declined by the base class.

        private static Utils utils = new Utils("SAMPLE", "$Workfile$", "$Revision$");
    }
}
