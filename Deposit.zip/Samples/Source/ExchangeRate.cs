/**********************************************************************************\

    ExchangeRate
    This module contains a sample Customer Transaction Object which implements
    an exchange rate transaction, converting a US$ amount entered by the customer
    to some other selected currency.
    
    Copyright (c) 2007 - 2017 KAL

\**********************************************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using K3A.Common;
using K3A.Platform;
using K3A.UserInterface;
using K3A.Hosts;
using K3A.CustomerApp;

namespace Samples
{
    /// <summary>
    /// This Customer Transaction Object implements an exchange rate
    /// transaction for converting a customer-entered US$ amounts to a
    /// selected currency.
    /// </summary>
    public class ExchangeRate : CustomerTransactionObject
    {
        public ExchangeRate()
            : base("ExchangeRate")
        {
            InitializeCounters();
            Authorization = new AuthorizationTransactionUnit("Authorization", this, TransactionHost.InquiryType.General);
            ReceiptHandler = new ReceiptHandlingTransactionUnit("ReceiptHandler", this);
        }

        public ExchangeRate(string id)
            : base("ExchangeRate", id)
        {
            InitializeCounters();
            Authorization = new AuthorizationTransactionUnit("Authorization", this, TransactionHost.InquiryType.General);
            ReceiptHandler = new ReceiptHandlingTransactionUnit("ReceiptHandler", this);
        }

        // Use AuthorizationTransactionUnit for authorizing transaction
        public AuthorizationTransactionUnit Authorization;

        // Use ReceiptHandlingTransactionUnit for handling receipt
        public ReceiptHandlingTransactionUnit ReceiptHandler;

        /// <summary>
        /// Initialize usage counters: these are reported by the DisplayUsage
        /// supervisor function.  See ExchangeRateUsage class.
        /// </summary>
        private void InitializeCounters()
        {
            usageCounters.Create(CountNumTransactions);
            usageCounters.Create(CountNumYenConversions);
            usageCounters.Create(CountNumEuroConversions);
        }

        // Names of counters used
        public static string CountNumTransactions = "NumTransactions";
        public static string CountNumYenConversions = "NumYenConversions";
        public static string CountNumEuroConversions = "NumEuroConversions";

        //////////////////////////////////////////////////////////////////
        // Configuration Properties

        /// <summary>
        /// List of currencies available for customer to select from.
        /// </summary>
        public object SelectableCurrencies
        {
            get
            {
                return new ArrayList(selectableCurrencies.Value);
            }
            set
            {
                selectableCurrencies.SetObject(value);
            }
        }

        EnumListConfigProperty selectableCurrencies = new EnumListConfigProperty("SelectableCurrencies", new string[] { "EUR", "GBP", "JPY", "AUD", "CAD", "CNY" }, new string[] { "EUR", "GBP", "JPY" });

        /// <summary>
        /// Timeout for customer reaction.
        /// </summary>
        public int CustomerTimeout
        {
            get
            {
                return customerTimeout.Value;
            }
            set
            {
                customerTimeout.Value = value;
            }
        }

        IntConfigProperty customerTimeout = new IntConfigProperty("CustomerTimeout", 30000, 1000, 600000);

        /////////////////////////////////////////////////////////////////
        // Properties

        /// <summary>
        /// The currency selected by the customer, or empty string if not yet selected.
        /// </summary>
        public string SelectedCurrency
        {
            get
            {
                return selectedCurrency;
            }
            set
            {
                selectedCurrency = value;
            }
        }

        private string selectedCurrency = "";
        // NOTE: Exposing the Selected Currency in this way makes it available to
        // customization script, for instance in order to print it on the receipt.
        // It also provides additional options for using the transaction in a more 
        // flexible way.  For example, top-level script might set SelectedCurrency
        // to GBP before calling the transaction: that would create a transaction
        // for converting USD amounts to GBP (currency selection would be skipped)

        /// <summary>
        /// The conversion rate for the selected currency as returned from LookupExchangeRate or zero if not yet known.
        /// </summary>
        public CashAmount ConversionRate
        {
            get
            {
                return conversionRate;
            }
            set
            {
                conversionRate = value;
            }
        }

        private CashAmount conversionRate = new CashAmount();

        /// <summary>
        /// The dollar amount entered by the customer for conversion.
        /// </summary>
        public CashAmount DollarAmount
        {
            get
            {
                return dollarAmount;
            }
            set
            {
                dollarAmount = value;
            }
        }

        private CashAmount dollarAmount = new CashAmount("USD", 0);

        /// <summary>
        /// The equivalent of the entered dollar amount in the other currency.
        /// </summary>
        public CashAmount ConvertedAmount
        {
            get
            {
                return convertedAmount;
            }
            set
            {
                convertedAmount = value;
            }
        }

        private CashAmount convertedAmount = new CashAmount();

        /// <summary>
        /// Indicates if this transaction is currently available.  The transaction is available as long as the host is.
        /// </summary>
        public override bool TransactionAvailable
        {
            get
            {
                if (!Authorization.HostAvailable)
                    return false;
                if (ReceiptHandler.ReceiptRequiredNotAvailable)
                    return false;
                return true;
            }
            set
            {
                transactionAvailable = value;
            }
        }

        /////////////////////////////////////////////////////////////////
        // Events

        /// <summary>
        /// Generated to prompt the customer to select a currency for the conversion.
        /// </summary>
        private SelectEvent SelectCurrencyEv = new SelectEvent("SelectCurrency");

        /// <summary>
        /// Generated to prompt the customer to enter the amount to convert.
        /// </summary>
        private EnterEvent EnterAmountEv = new EnterEvent("EnterAmount");

        /// <summary>
        /// Generated to update display during amount entry.
        /// </summary>
        private UpdateEvent EnterAmountUpdate = new UpdateEvent("EnterAmountUpdate");

        /// <summary>
        /// Sent before the application sends the exchange rate query to the host.
        /// </summary>
        private UIEvent RateLookupAdvice = new UIEvent("RateLookupAdvice");

        /// <summary>
        /// Sent when the exchange rate query to the host fails.
        /// </summary>
        private UIEvent RateUnknownAdvice = new UIEvent("RateUnknownAdvice");

        /// <summary>
        /// Sent for the converted amount to be displayed on screen.  The ConvertedAmount property
        /// gives the amount for display.  After sending this event, the transaction then waits for
        /// the customer to confirm or request a printed receipt (if configured).
        /// </summary>
        private ShowConvertedAmountEvent ShowConvertedAmount = new ShowConvertedAmountEvent();

        /////////////////////////////////////////////////////////////////
        // Documents

        /////////////////////////////////////////////////////////////////
        // Methods

        /// <summary>
        /// Standard method: clear transaction related data.
        /// </summary>
        public override void NewTransaction()
        {
            selectedCurrency = "";
            conversionRate = new CashAmount();
            dollarAmount = new CashAmount("USD", 0);
            convertedAmount = new CashAmount();
        }

        /// <summary>
        /// This method performs the complete transaction, prompting the customer
        /// to select a currency, then enter the amount to be converted, it then
        /// =retrieves the exchange rate from the host and finally reports the conversion
        /// result to the customer.
        /// </summary>
        public void Execute()
        {
            NewTransaction();

            SelectCurrency();

            EnterAmount();

            LookupExchangeRate();

            ReportConversion();
        }

        /// <summary>
        /// Prompts the customer to select one of the configured SelectableCurrencies for
        /// the conversion.
        /// </summary>
        public void SelectCurrency()
        {
            StartMethod("SelectCurrency");

            // Check if transaction was already cancelled (note: this may be true if
            // EnterAmount was called first from top-level script, customer cancelled
            // transaction, then this method was called from script)
            if (TransactionInterrupt)
            {
                EndMethod();
                return;
            }

            // If currency was already selected (perhaps from top-level script)
            // then return right away
            if (selectedCurrency.Length > 0)
            {
                EndMethod();
                return;
            }

            // Store available currencies in selection event
            SelectCurrencyEv.Options = new ArrayList(selectableCurrencies.Value);

            // Loop until customer selects a currency or cancels
            bool selectionComplete = false;
            while (!selectionComplete)
            {
                CustomerUI.ProcessEvent(SelectCurrencyEv);

                bool gotInput = CustomerUI.WaitForInput(CustomerTimeout);
                CustomerUI.InteractionComplete();

                // Timeout handling
                if (!gotInput)
                {
                    // Ask the customer if they would like more time
                    if (CustomerObjects.Customer.MoreTime())
                        continue;   // Customer wants more time
                    else
                        throw new WrapupException(WrapupException.WrapupReason.CustomerTimeout);
                }

                // Retrieve & handle customer input
                string input = CustomerUI.GetInput();
                if (HandleCommonCustomerInputs(input))
                {
                    EndMethod();
                    return;
                }

                // Otherwise should be one of the available currencies
                if (!selectableCurrencies.Value.Contains(input))
                    throw new WrapupException(WrapupException.WrapupReason.ScriptError, "Invalid currency selected:" + input + ".  Selected currency must be one of the configured SelectableCurrencies event.");

                selectedCurrency = input;
                selectionComplete = true;
            }

            EndMethod();
        }

        /// <summary>
        /// Prompts the customer to enter the US$ amount they want to convert.
        /// Note that an AmountSelectorTransactionUnit might be used instead of implementing amount entry here.
        /// </summary>
        public void EnterAmount()
        {
            StartMethod("EnterAmount");

            // Check if transaction was already cancelled
            if (TransactionInterrupt)
            {
                EndMethod();
                return;
            }

            // If the amount to be converted was already set, return right away
            if (DollarAmount.Value > 0)
            {
                EndMethod();
                return;
            }

            // Prompt customer to enter an amount.  Initialise update event.
            CustomerUI.ProcessEvent(EnterAmountEv);

            EnterAmountUpdate.Entry = "$0.00";
            EnterAmountUpdate.RawEntry = "";

            // Loop until amount entry complete
            bool entryComplete = false;
            while (!entryComplete)
            {
                bool gotInput = CustomerUI.WaitForInput(CustomerTimeout);

                // Timeout handling
                if (!gotInput)
                {
                    // Ask the customer if they would like more time
                    if (CustomerObjects.Customer.MoreTime())
                    {
                        // Customer wants more time: resend events to restore display 
                        CustomerUI.ProcessEvent(EnterAmountEv);
                        CustomerUI.ProcessEvent(EnterAmountUpdate);
                        continue;
                    }
                    else
                        throw new WrapupException(WrapupException.WrapupReason.CustomerTimeout);
                }

                // Retrieve and process customer input
                string input = CustomerUI.GetInput();
                if (HandleCommonCustomerInputs(input))
                {
                    EndMethod();
                    return;
                }
                else if (input == "ENTER")
                {
                    // Enter key signals completion of entry
                    CustomerUI.InteractionComplete();

                    // Restart amount entry if the customer didn't enter anything
                    // Note: could also add an InvalidAmountAdvice event for this
                    if (EnterAmountUpdate.RawEntry == "")
                    {
                        CustomerUI.ProcessEvent(EnterAmountEv);
                        continue;
                    }

                    // Convert customer entry to an integer value
                    int enteredAmount = 0;
                    bool ok = Int32.TryParse(EnterAmountUpdate.RawEntry, out enteredAmount);
                    utils.Test(ok, "Invalid amount entered:" + EnterAmountUpdate.RawEntry);

                    // Save entered amount & we're done
                    dollarAmount = new CashAmount("USD", enteredAmount);
                    entryComplete = true;
                }
                else if (input == "CLEAR")
                {
                    // Clear key pressed: clear display
                    EnterAmountUpdate.Entry = "$0.00";
                    EnterAmountUpdate.RawEntry = "";
                    CustomerUI.ProcessEvent(EnterAmountUpdate);
                }
                else
                {
                    // Otherwise customer input should be a digit: append this to
                    // the amount entered so far and update the display
                    if (input.Length == 0 ||
                        input[0] < '0' || input[0] > '9')
                        throw new WrapupException(WrapupException.WrapupReason.ScriptError, "Invalid input from user interface: expected digit or terminator key, got:" + input);

                    EnterAmountUpdate.RawEntry = EnterAmountUpdate.RawEntry + input;

                    int enteredAmount = 0;
                    bool ok = Int32.TryParse(EnterAmountUpdate.RawEntry, out enteredAmount);
                    utils.Test(ok, "Invalid amount entered:" + EnterAmountUpdate.RawEntry);

                    CashAmount amount = new CashAmount("USD", enteredAmount);
                    EnterAmountUpdate.Entry = amount.Format("$###,###,###,##0.00");

                    // Echo amount entered so far back to UI
                    CustomerUI.ProcessEvent(EnterAmountUpdate);
                }
            }
        }

        /// <summary>
        /// Retrieves the US$ exchange rate with the selected currency from the host.
        /// The return value is the equivalent of US$100 in the selected other currency.
        /// </summary>
        public CashAmount LookupExchangeRate()
        {
            StartMethod("LookupExchangeRate");

            // Check for transaction cancelled
            if (TransactionInterrupt)
            {
                EndMethod();
                return conversionRate;
            }

            // In order to lookup the exchange rate, we have to know the currency
            // we're converting too: if this wasn't set yet, it indicates an error
            // in customization code & we through a wrapup exception
            if (selectedCurrency.Length == 0)
                throw new WrapupException(WrapupException.WrapupReason.ScriptError, "LookupExchangeRate called before conversion currency selected.");


            // Let the UI know we're starting the host query
            CustomerUI.ProcessEvent(RateLookupAdvice);

            // Use Authorization TransactionUnit for doing authorization. 
            // For General Inquiry, we must set up the input fields for the query first.
            Dictionary<string, object> queryFields = new Dictionary<string,object>();
            queryFields.Add("FromCurrency", "USD");
            queryFields.Add("ToCurrency", selectedCurrency);

            Authorization.AuthorizeInquiry("ExchangeRate", new CashAmount(), new CashAmount(), queryFields);

            // Transaction was authorized: conversion rate should have been returned
            // in the Amount field of the authorization result
            conversionRate = Authorization.AuthorizationResult.Amount;

            // The conversion rate returned should be in the 'to' currency
            // If its not, treat this as a comms error.
            if (conversionRate == null ||
                conversionRate.Currency != selectedCurrency)
                throw new WrapupException(WrapupException.WrapupReason.CommsError, "Host returned null conversion rate or conversion rate for incorrect currency.");

            // Transaction succeeded: update counters
            usageCounters.Increment(CountNumTransactions);
            if (selectedCurrency == "JPY")
                usageCounters.Increment(CountNumYenConversions);
            else if (selectedCurrency == "EUR")
                usageCounters.Increment(CountNumEuroConversions);

            EndMethod(conversionRate);
            return conversionRate;
        }

        /// <summary>
        /// Reports the amount conversion result to the customer, giving the option
        /// to received a printed receipt showing the information.
        /// </summary>
        public void ReportConversion()
        {
            StartMethod("ReportConversion");

            // Check for transaction cancelled
            if (TransactionInterrupt)
            {
                EndMethod();
                return;
            }

            // We must know the value to be converted and must have retrieved 
            // the conversion rate to proceed
            if (dollarAmount.Value == 0 ||
                conversionRate.Value == 0)
            {
                throw new WrapupException(WrapupException.WrapupReason.ScriptError, "ReportConversion called before currency selected, amount entered or exchange rate known.");
            }

            // Conversion rate is the 'to' currency equivalent of $100
            // or of 10,000 US cents, which is the unit in which dollar amounts
            // are expressed.
            Int64 toValue = (dollarAmount.Value64 * conversionRate.Value64) / 10000;
            convertedAmount = new CashAmount(selectedCurrency, toValue);


            // Wait for UI to send OK, to confirm, or PRINT for a receipt
            bool printRequested = false;
            bool selectCompleted = false;
            while (!selectCompleted)
            {
                // Send event for converted amount to be shown on screen
                ShowConvertedAmount.ConvertedAmount = convertedAmount;
                CustomerUI.ProcessEvent(ShowConvertedAmount);

                bool gotInput = CustomerUI.WaitForInput(CustomerTimeout);
                CustomerUI.InteractionComplete();

                // Timeout handling
                if (!gotInput)
                {
                    // Ask the customer if they would like more time
                    if (CustomerObjects.Customer.MoreTime())
                        continue;
                    else
                        throw new WrapupException(WrapupException.WrapupReason.CustomerTimeout);
                }

                string input = CustomerUI.GetInput();
                if (input == "PRINT")
                {
                    selectCompleted = true;
                    printRequested = true;

                }
                else if (input == "OK")
                {
                    selectCompleted = true;
                }
                else if (input == "CANCEL")
                    throw new WrapupException(WrapupException.WrapupReason.CustomerCancel);
                else
                    throw new WrapupException(WrapupException.WrapupReason.ScriptError, "Screen sent invalid input: " + input + ".  Expected PRINT, OK or CANCEL in response to ShowConvertedAmount event");
            }

            // Print receipt now if requested
            if (printRequested)
            {
                ReceiptHandler.ReceiptAccepted = true;
                ReceiptHandler.ReceiptProcessing(true);
            }

            EndMethod();
        }

        private Counters usageCounters = new Counters("ExchangeRate");
        static private Utils utils = new Utils("SAMPLES", "$WorkFile$", "$Revision$");
    }

    [ComVisible(true), Serializable()]
    public class ShowConvertedAmountEvent : UIEvent
    {
        public ShowConvertedAmountEvent()
            : base("ShowConvertedAmount")
        {
        }

        public override UIEvent Clone()
        {
            ShowConvertedAmountEvent e = new ShowConvertedAmountEvent();
            e.convertedAmount = convertedAmount;
            return e;
        }

        public CashAmount ConvertedAmount
        {
            get
            {
                return convertedAmount;
            }
            set
            {
                convertedAmount = value;
            }
        }

        CashAmount convertedAmount;
    }
}
