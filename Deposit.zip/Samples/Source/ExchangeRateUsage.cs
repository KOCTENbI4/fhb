/**********************************************************************************\

    ExchangeRateUsage
    This module contains a sample Supervisor Transaction Object which implements
    a function for viewing and clearing ExchangeRate usage stats.
    
    Copyright (c) 2007 - 2017 KAL

\**********************************************************************************/
using System;
using System.Runtime.InteropServices;
using K3A.Common;
using K3A.Platform;
using K3A.UserInterface;
using K3A.SupervisorApp;

namespace Samples
{
    /// <summary>
        /// This sample Supervisor Transaction Object exports just one function for
        /// displaying and optionally printing usage counters associated with the
        /// ExchangeRate transaction.
        /// </summary>
    public class ExchangeRateUsage : SupervisorObject
    {
        public ExchangeRateUsage() 
            : base("ExchangeRateUsage")
        {
        }

        public ExchangeRateUsage(string id)
            : base("ExchangeRateUsage", id)
        {
        }

        //////////////////////////////////////////////////////////////////
        // Configuration Properties

        // No configuration properties needed for this object.  If required, 
        // configuration properties could be added here using the same
        // approach shown in the ExchangeRate object.

        /////////////////////////////////////////////////////////////////
        // Properties

        // NOTE: Expose counters as properties so they're available for use in 
        // customization code, for instance in order to print out

        /// <summary>
        /// Number of ExchangeRate transactions since last cleared
        /// </summary>
        public int NumTransactions
        {
            get
            {
                return usageCounters.GetValue(ExchangeRate.CountNumTransactions);
            }
        }

        /// <summary>
        /// Number of ExchangeRate Yen conversions since last cleared
        /// </summary>
        public int NumYenConversions
        {
            get
            {
                return usageCounters.GetValue(ExchangeRate.CountNumYenConversions);
            }
        }

        /// <summary>
        /// Number of ExchangeRate Euro conversions since last cleared
        /// </summary>
        public int NumEuroConversions
        {
            get
            {
                return usageCounters.GetValue(ExchangeRate.CountNumEuroConversions);
            }
        }

        // Note: only Yen and Euro counters are supported currently: others could be
        // added in the same way.  Alternatively, counter names might be created dynamically
        // in order to provide more generic support.

        /// <summary>
        /// Date and time counters were last cleared.
        /// </summary>
        public DateAndTime LastCleared
        {
            get
            {
                return usageCounters.GetLastCleared(ExchangeRate.CountNumTransactions);
            }
        }

        /////////////////////////////////////////////////////////////////
        // Events

        /// <summary>
        /// Generated when usage figures should be displayed.  The event has properties
        /// NumTransactions, NumYenConversions, NumEuroConversions and LastCleared.
        /// </summary>
        private DisplayUsageEvent DisplayUsageEv = new DisplayUsageEvent();

        /// <summary>
        /// Generated on completion of the usage function.
        /// </summary>
        private CompletionEvent DisplayUsageComplete = new CompletionEvent("DisplayUsageComplete");

        /////////////////////////////////////////////////////////////////
        // Documents

        /// <summary>
        /// Document used to print out usage information if requested.
        /// </summary>
        Document UsageInfo = new Document("UsageInfo", Document.PrinterType.ReceiptPrinter);

        /////////////////////////////////////////////////////////////////
        // Methods

        /// <summary>
        /// This function displays usage figures for the ExchangeRate transaction, then
        /// gives the operator the options or printing or clearing usage counts or exiting.
        /// </summary>
        public void DisplayUsage()
        {
            StartMethod("DisplayUsage");

            // Note: commit counters before displaying
            // This ensures counter values about to be displayed persist to 
            // the following time the demo is run.  (Normally not needed, but
            // avoids losing counters in the case demo is stopped and started often.)
            usageCounters.Commit();

            // Send an DisplayUsage event to the UI containing totals
            // Note: use date and time NumTransactions was last cleared.  All counters
            // are cleared at the same time, so this timestamp should be the same for all.
            DisplayUsageEv.NumTransactions = NumTransactions;
            DisplayUsageEv.NumYenConversions = NumYenConversions;
            DisplayUsageEv.NumEuroConversions = NumEuroConversions;
            DisplayUsageEv.LastCleared = LastCleared;
            SupervisorUI.ProcessEvent(DisplayUsageEv);

            // Now wait for operator to request PRINT/CLEAR/EXIT
            bool exit = false;
            while (!exit)
            {
                SupervisorUI.WaitForInput(-1);
                string input = SupervisorUI.GetInput();

                if (input == "PRINT")
                {
                    utils.Test(UsageInfo.IsReadyToPrint, "Operator requested print when document not configured.");

                    bool ok = UsageInfo.ProcessSync();
                    if (!ok)
                    {
                        DisplayUsageComplete.Succeeded = false;
                        DisplayUsageComplete.Reason = "PrintError";
                        SupervisorUI.ProcessEvent(DisplayUsageComplete);
                        EndMethod();
                        return;
                    }
                }
                else if (input == "CLEAR")
                {
                    usageCounters.Clear(ExchangeRate.CountNumTransactions);
                    usageCounters.Clear(ExchangeRate.CountNumYenConversions);
                    usageCounters.Clear(ExchangeRate.CountNumEuroConversions);

                    // Send another DisplayUsage event to update display
                    DisplayUsageEv.NumTransactions = NumTransactions;
                    DisplayUsageEv.NumYenConversions = NumYenConversions;
                    DisplayUsageEv.NumEuroConversions = NumEuroConversions;
                    DisplayUsageEv.LastCleared = LastCleared;

                    SupervisorUI.ProcessEvent(DisplayUsageEv);
                }
                else
                {
                    utils.Test(input == "EXIT", "Unexpected input from operator:" + input + ". Expected PRINT, CLEAR or EXIT.");
                    exit = true;
                }
            }

            // Send completion event before exiting
            DisplayUsageComplete.Succeeded = true;
            SupervisorUI.ProcessEvent(DisplayUsageComplete);

            EndMethod();
        }

        private Counters usageCounters = new Counters("ExchangeRate");
        static private Utils utils = new Utils("SAMPLES", "$WorkFile$", "$Revision$");
    }

    [ComVisible(true), Serializable()]
    public class DisplayUsageEvent : UIEvent
    {
        public DisplayUsageEvent()
            : base("DisplayUsage")
        {
        }

        public override UIEvent Clone()
        {
            DisplayUsageEvent e = new DisplayUsageEvent();
            e.NumTransactions = NumTransactions;
            e.NumYenConversions = NumYenConversions;
            e.NumEuroConversions = NumEuroConversions;
            e.LastCleared = LastCleared;
            return e;
        }

        public int NumTransactions
        {
            get
            {
                return numTransactions;
            }
            set
            {
                numTransactions = value;
            }
        }

        private int numTransactions;

        public int NumYenConversions
        {
            get
            {
                return numYenConversions;
            }
            set
            {
                numYenConversions = value;
            }
        }

        private int numYenConversions;

        public int NumEuroConversions
        {
            get
            {
                return numEuroConversions;
            }
            set
            {
                numEuroConversions = value;
            }
        }

        private int numEuroConversions;

        public DateAndTime LastCleared
        {
            get
            {
                return lastCleared;
            }
            set
            {
                lastCleared = value;
            }
        }

        private DateAndTime lastCleared;
    }
}
